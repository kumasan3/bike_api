FactoryBot.define do
  factory :brand do
    name { 'SUZUKI' }
  end
end
