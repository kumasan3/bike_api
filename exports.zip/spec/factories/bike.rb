FactoryBot.define do
  factory :bike do
    sequence(:serial_number) { |n| 'serial_' + n.to_s }
  end
end
